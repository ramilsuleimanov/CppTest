# -*- coding: cp1251 -*-
"""
Created on Tue Jun 22 10:34:01 2021

@author: r.suleimanov
"""
import pickle
from datetime import datetime
import os
import time
import quickfix as fix
import quickfix44 as fix44
from loguru import logger

logger.add("C:\\Users\\r.suleimanov\\Documents\\Python\\KASE\\client_repo.log",
           format = "{time:DD.MM.YYYY HH:mm:ss};{level};{name};{module};{function};{message}",
           level="DEBUG")

if os.getcwd() != "C:\\Users\\r.suleimanov\\Documents\\Python\\KASE\\":
    os.chdir("C:\\Users\\r.suleimanov\\Documents\\Python\\KASE\\")

__SOH__ = chr(1)

def saveID(orderID, execID):
    filename = ".".join([datetime.now().strftime("%d%m%Y"),"pckl"])
    file = open(filename, "wb")
    pickle.dump([orderID, execID], file)
    file.close()
    logger.debug(f"Saved datas to file: {filename}. OrderID is: {orderID} and execID is: {execID}")

    

class Application(fix.Application):
    
    filename = ".".join([datetime.now().strftime("%d%m%Y"),"pckl"])
    if os.path.exists(filename):        
        file = open(filename, "rb")
        orderID, execID = pickle.load(file)
        file.close()
        logger.debug(f"Readed datas from file: {filename}. OrderID is: {orderID} and execID is: {execID}")        
    else:
        orderID = 0
        execID = 0
        logger.debug("Created new orderID and execID")        
    isLogon = False
    
    def __init__(self, settings):
        super(Application, self).__init__()
        self.Settings = settings

    def genOrderID(self):
        self.orderID += 1
        return self.orderID

    def genExecID(self):
        self.execID += 1
        return str(self.execID)

    def onCreate(self, sessionID):
        self.sessionID = sessionID
        logger.debug(f"Application created. Session ID: {sessionID.toString()}")
        return 

    def onLogon(self, sessionID):
        self.sessionID = sessionID
        logger.debug(f"Successful Logon. Session ID: {sessionID.toString()}")
        self.isLogon = True
        return
    
    def onLogout(self, sessionID):
        logger.debug(f"Session ID: {sessionID.toString()} is logout !")
        return

    def toAdmin(self, message, sessionID):
        # msgType = fix.MsgType()
        # message.getHeader().getField(msgType)
        saveID(self.orderID, self.execID)
        msg = message.toString().replace(__SOH__, "|")
        logger.debug(f"Sending Admin message to server.\nMessage: {msg}") 

    def toApp(self, message, sessionID):
        saveID(self.orderID, self.execID)
        msg = message.toString().replace(__SOH__, "|")
        logger.debug(f"Sending Application message to server.\nMessage: {msg}")
        return

    def fromAdmin(self, message, sessionID):
        msg = message.toString().replace(__SOH__, "|")
        logger.debug(f"Received Admin message from server.\nMessage: {msg}")
        return

    def fromApp(self, message, sessionID):
        msgType = fix.MsgType()
        message.getHeader().getField(msgType)
        logger.debug(msgType.getValue())
        msg = message.toString().replace(__SOH__, "|")
        logger.debug(f"Received Application message from server.\nMessage: {msg}")
        return

    def placeOrder(self):
        try:
            logger.debug("New Order Single")            
            msg = fix44.NewOrderSingle()
            # Standard Header Tags
            msg.getHeader().setField(self.sessionID.getSenderCompID())
            msg.getHeader().setField(self.sessionID.getTargetCompID())
            msg.getHeader().setField(fix.MsgSeqNum(self.genOrderID()))
            sendingTime = fix.SendingTime()
            sendingTime.setString(datetime.utcnow().strftime("%Y%m%d-%H:%M:%S.%f"))
            msg.getHeader().setField(sendingTime)
            # New Order Single Tags
            tranactionTime = fix.TransactTime()
            tranactionTime.setString(datetime.utcnow().strftime("%Y%m%d-%H:%M:%S.%f"))
            msg.setField(tranactionTime)
            msg.setField(fix.ClOrdID(self.genExecID()))
            msg.setField(fix.OrdType("2"))
            msg.setField(fix.Symbol("SAQ1"))
            msg.setField(fix.Account("002"))
            msg.setField(fix.Side("1"))
            msg.setField(fix.OrderQty(17))
            msg.setField(fix.Price(3430.00))
            group = fix44.NewOrderSingle().NoPartyIDs()
            group.setField(fix.PartyID("UR01"))
            group.setField(fix.PartyIDSource("C"))
            group.setField(fix.PartyRole(7))
            msg.addGroup(group)
            logger.debug(msg.toString().replace(__SOH__, "|"))
            fix.Session.sendToTarget(msg, self.sessionID)
        
        except Exception as e:
            logger.debug(e)
            
    def orderStatusReq(self):
        try:
            logger.debug("Order Status Request")
            msg = fix44.OrderStatusRequest()
            # Standard Header Tags
            msg.getHeader().setField(self.sessionID.getSenderCompID())
            msg.getHeader().setField(self.sessionID.getTargetCompID())
            msg.getHeader().setField(fix.MsgSeqNum(self.genOrderID()))
            sendingTime = fix.SendingTime()
            sendingTime.setString(datetime.utcnow().strftime("%Y%m%d-%H:%M:%S.%f"))
            msg.getHeader().setField(sendingTime)
            # Order Status Request Tags
            msg.setField(fix.OrderID("6755889067327489"))
            msg.setField(fix.Symbol("SAQ1"))
            msg.setField(fix.Side("1"))
            msg.setField(fix.OrdStatusReqID("N13082021_1"))
            logger.debug(msg.toString().replace(__SOH__, "|"))
            fix.Session.sendToTarget(msg, self.sessionID)
        
        except Exception as e:
            logger.debug(e)
            
    def orderCancelReq(self):
        try:
            logger.debug("Order Cancel Request")
            msg = fix44.OrderCancelRequest()
            # Standard Header Tags
            msg.getHeader().setField(self.sessionID.getSenderCompID())
            msg.getHeader().setField(self.sessionID.getTargetCompID())
            msg.getHeader().setField(fix.MsgSeqNum(self.genOrderID()))
            sendingTime = fix.SendingTime()
            sendingTime.setString(datetime.utcnow().strftime("%Y%m%d-%H:%M:%S.%f"))
            msg.getHeader().setField(sendingTime)
            # Order Status Request Tags
            group = fix44.NewOrderSingle().NoPartyIDs()
            group.setField(fix.PartyID("UR02"))
            group.setField(fix.PartyIDSource("C"))
            group.setField(fix.PartyRole(7))
            msg.addGroup(group)
            msg.setField(fix.OrderID())
            msg.setField(fix.Symbol("SAQ1"))
            msg.setField(fix.Side("1"))
            tranactionTime = fix.TransactTime()
            tranactionTime.setString(datetime.utcnow().strftime("%Y%m%d-%H:%M:%S.%f"))
            msg.setField(fix.OrderQty(10))
            #msg.setField(fix.OrdStatusReqID("N13082021_1"))
            logger.debug(msg.toString().replace(__SOH__, "|"))
            fix.Session.sendToTarget(msg, self.sessionID)
        
        except Exception as e:
            logger.debug(e)
            
    def testRequests(self):
        try:
            logger.debug("Test Request")
            msg = fix44.TestRequest()
            # Standard Header Tags
            msg.getHeader().setField(self.sessionID.getSenderCompID())
            msg.getHeader().setField(self.sessionID.getTargetCompID())
            msg.getHeader().setField(fix.MsgSeqNum(self.genOrderID()))
            sendingTime = fix.SendingTime()
            sendingTime.setString(datetime.utcnow().strftime("%Y%m%d-%H:%M:%S.%f"))
            msg.getHeader().setField(sendingTime)
            # Test Request Tags
            msg.setField(fix.TestReqID("TestReq"))
            logger.debug(msg.toString().replace(__SOH__, "|"))
            fix.Session.sendToTarget(msg, self.sessionID)
        
        except Exception as e:
            logger.debug(e)

try:
    settings = fix.SessionSettings("config_spectra.cfg")
    application = Application(settings)

    storeFactory = fix.FileStoreFactory(settings)
    logFactory = fix.ScreenLogFactory(settings)

    initiator = fix.SocketInitiator(application, storeFactory, settings, logFactory)
    initiator.start()
    time.sleep(5)
    
    if application.isLogon:
        # application.orderCancelReq()
        # application.orderStatusReq()
        # time.sleep(5)
        application.placeOrder()
        time.sleep(60)        
    # application.placeOrder("S+1033600000", "GCBRK", "EBRP", "2", 15.00, 10.00, "2", "REPO")  
    # time.sleep(5)    
    # application.placeOrder("S+1033600000", "GCBRK", "EBRP", "1", 10.00, 10.00, "2", "REPO",\
    #                        "MUM120_0017")
    # # time.sleep(5)    
    # application.placeOrder("S+1033600000", "GCBRK", "EBRP", "1", 10.00, 10.00, "2", "REPO",\
    #                        "MUM1200017")
    # time.sleep(5) 
    # application.placeOrder("S+1033600000", "GCBRK", "EBRP", "2", 10.00, 10.00, "2", "REPO",\
    #                        "MUM1200017")
    # time.sleep(5) 
    # application.placeOrder("S+1033600000", "GCBRK", "EBRP", "1", 10.00, 10.00, "2", "REPO")
    
    # application.placeOrder("I+1033600252", "GCBRK", "EBRP", "1", 10.00, 10.00, "2", "REPO", "MUM1200017")
    # time.sleep(5)
    # application.placeOrder("I+1033600252", "GCBRK", "EBRP", "1", 10.00, 10.00, "2", "REPO", "MUM120_0017")  
    # time.sleep(5)
    # application.testRequests()
    time.sleep(5)
    initiator.stop()
    
except (fix.ConfigError, fix.RuntimeError) as e:
    logger.debug(e)





